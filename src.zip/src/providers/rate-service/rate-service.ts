
import { Injectable } from '@angular/core';
import { Platform } from 'ionic-angular';
import { AppRate } from '@ionic-native/app-rate';
/*
  Generated class for the RateServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  promptForRating(): any {
    throw new Error("Method not implemented.");  [x: string]: any;  promptForRating(arg0: any): any {
    throw new Error("Method not implemented.");
  }

  promptForRating: any;

  }
  and Angular DI.
*/
@Injectable()
export class RateServiceProvider {
  
  constructor(public platform: Platform,public appRate: AppRate) {
    console.log('Hello RateServiceProvider Provider');
    this.platform.ready().then(
      () => {
        this.appRate.preferences.storeAppURL = {
          ios: '849930087',
          android: 'market://details?id=com.ionic.test',
          windows: 'ms-windows-store://pdp/?ProductId=9nblggh1z0w3',
        };
        this.appRate.preferences.usesUntilPrompt = 2;
        this.appRate.preferences.customLocale = {
          title: "Rate Crafting Coach",
          message: "If you enjoy using Crafting Coach, please rate and review it.",
          cancelButtonLabel: "No, Thanks",
          laterButtonLabel: "Remind Me Later",
          rateButtonLabel: "Rate It Now"
        };
      }      
    )
  }
  }


