<?php
header("Access-Control-Allow-Origin: *");

$data = json_decode(file_get_contents("php://input"));
$username = $data->nickname;
$email = $data->email;
$pssword = $data->password;

$conn = news mysqli('localhost', 'username', 'password', 'database');
 if($conn->connect_error){
     die("Connection failed:" . $conn->connect_error);
 }
 $sql2 = "SELECT 'email' FROM 'registered_members' WHERE 'email' = '".$email"' ";

 $result2 = $conn->query($sql2);
 if($result2->num_rows > 0){
     echo json_encode(array("data"->'',"message"->"error"));

 }
 else{
     $sql = "INSERT INTO 'registered_members'('name', 'email', 'password') VALUES ('" .$username."', '".$email."', '".$password."')";
 if($conn->query($sql) === TRUE){
     $last_id = $conn->insert_id;
     echo json_encode(array("data"=> 'Registeration succesfully . your id is '.$last_id, "message"=>"success"));

 }
 else{
     echo json_encode(array("data"->'',"message"->"error"));

 }
    }

 }
 $conn->close();
 ?>